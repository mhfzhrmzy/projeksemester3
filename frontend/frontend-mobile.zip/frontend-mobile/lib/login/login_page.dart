import 'package:flutter/material.dart';
import '../common/theme/auth_colors.dart';
import '../common/widgets/auth_header.dart';
import '../common/widgets/auth_avatar_icon.dart';
import '../common/widgets/auth_text_field.dart';
import '../register/register_page.dart';
import '../views/beranda/beranda_view.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _namaController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  void dispose() {
    _namaController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  void _login() {
    // TODO: validasi kredensial ke API
    // Sementara langsung masuk ke Beranda
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => const BerandaView(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Padding horizontal selaras dengan TestPage (Pre/Post-Test)
    final double hp = (MediaQuery.of(context).size.width * 0.075).clamp(22.0, 40.0);

    return Scaffold(
      backgroundColor: kBackground,
      body: SingleChildScrollView(
        child: Column(
          children: [
            const AuthHeader(title: 'Login'),
            const SizedBox(height: 30),
            const AuthAvatarIcon(),
            const SizedBox(height: 28),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: hp),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: kCardBorder.withValues(alpha: 0.4)),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withValues(alpha: 0.06),
                      blurRadius: 16,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AuthTextField(
                      label: 'Nama Lengkap',
                      hint: 'Masukkan nama lengkap',
                      controller: _namaController,
                    ),
                    const SizedBox(height: 14),
                    AuthTextField(
                      label: 'Password',
                      hint: 'Masukkan password',
                      obscure: true,
                      controller: _passwordController,
                    ),
                    const SizedBox(height: 14),
                    RichText(
                      text: TextSpan(
                        text: 'Apakah sudah punya akun? Jika belum ',
                        style: const TextStyle(fontSize: 12, color: Colors.black54),
                        children: [
                          WidgetSpan(
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (_) => const RegisterPage(),
                                  ),
                                );
                              },
                              child: const Text(
                                'registrasi',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: kMaroon,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20),
                    Align(
                      alignment: Alignment.centerRight,
                      child: ElevatedButton(
                        onPressed: _login,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: kMaroon,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 36, vertical: 13),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                          ),
                          elevation: 4,
                        ),
                        child: const Text(
                          'Masuk',
                          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}
